const server = require('./server');

function init() {
  server.start();
}

init();
